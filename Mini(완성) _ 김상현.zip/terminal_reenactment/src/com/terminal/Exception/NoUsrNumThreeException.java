package com.terminal.Exception;

public class NoUsrNumThreeException extends Exception{
	
	public NoUsrNumThreeException(String msg) {
		super(msg);
	}
	

}
